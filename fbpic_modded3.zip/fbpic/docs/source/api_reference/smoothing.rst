Field smoothing
===============

.. autoclass:: fbpic.fields.smoothing.BinomialSmoother
