Flattened Gaussian profile
**************************

.. autoclass:: fbpic.lpa_utils.laser.FlattenedGaussianLaser