Donut-like Laguerre-Gauss profile
*********************************

.. autoclass:: fbpic.lpa_utils.laser.DonutLikeLaguerreGaussLaser
