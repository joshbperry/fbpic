Few-cycle profile
*****************

.. autoclass:: fbpic.lpa_utils.laser.FewCycleLaser
