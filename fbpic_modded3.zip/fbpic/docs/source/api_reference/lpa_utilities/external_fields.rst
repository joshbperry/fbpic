External fields
===============

**External fields** are fields which are applied to the particles at each 
timestep and are **specified by the user**, instead of being self-consistently 
evolved by the simulation.

.. autoclass:: fbpic.lpa_utils.external_fields.ExternalField
