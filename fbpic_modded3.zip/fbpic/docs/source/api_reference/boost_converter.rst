Conversion to boosted-frame
===========================

.. autoclass:: fbpic.lpa_utils.boosted_frame.BoostConverter
   :members:
