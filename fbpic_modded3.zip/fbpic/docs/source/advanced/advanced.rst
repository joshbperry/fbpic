Advanced use
============

This section contains several tips, that can help you get
more performance and faster results from the code.

**Topics:**

.. toctree::
   :maxdepth: 1

   profiling
   parameter_scans
   boosted_frame
   3d_visualization
