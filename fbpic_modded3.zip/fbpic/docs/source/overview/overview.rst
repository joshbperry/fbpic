Overview of the code
====================

The following two short sections give an basic overview of how FBPIC works.
In order to properly use the code, it is important to read them.

**Topics:**

.. toctree::
   :maxdepth: 1

   pic_algorithm
   parallelisation
