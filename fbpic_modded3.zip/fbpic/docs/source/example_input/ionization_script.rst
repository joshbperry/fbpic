Laser-wakefield acceleration with ionization
--------------------------------------------

You can download the script below by clicking on :download:`this link <ionization_script.py>`.

.. literalinclude:: ionization_script.py
   :language: python