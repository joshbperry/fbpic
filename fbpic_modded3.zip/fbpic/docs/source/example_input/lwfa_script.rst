Standard simulation of laser-wakefield acceleration
---------------------------------------------------

You can download the script below by clicking on :download:`this link <lwfa_script.py>`.

.. literalinclude:: lwfa_script.py
   :language: python