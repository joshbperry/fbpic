Boosted-frame simulation of laser-wakefield acceleration
--------------------------------------------------------

You can download the script below by clicking on :download:`this link <boosted_frame_script.py>`.

.. literalinclude:: boosted_frame_script.py
   :language: python